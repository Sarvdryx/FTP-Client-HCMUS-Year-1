import utils
import socket
import os
import re
import globals
import operations
import ftp_core as ftp
from pathlib import Path
import threading
import tkinter as tk
from tkinter import messagebox

ClamAV_HOST = "192.168.17.129"
ClamAV_PORT = 5001
BUFFER_SIZE = 4096

def sendToClamAV(filepath):
    with socket.socket() as s:
        s.connect((ClamAV_HOST, ClamAV_PORT))

        filename = os.path.basename(filepath)
        s.sendall((filename + "\n").encode())

        with open(filepath, 'rb') as f:
            while chunk := f.read(BUFFER_SIZE):
                s.sendall(chunk)

        s.shutdown(socket.SHUT_WR) 

        s.settimeout(300)
        result = b""
        while True:
            data = s.recv(BUFFER_SIZE)
            if not data:
                break
            result += data

    if "OK" in result.decode():
        return "OK"
    else:
        return "INFECTED"


def listFileOnClient():
    arr = []
    current_dir = Path.cwd() 

    for f in current_dir.iterdir():
        if f.is_file():
            arr.append(f.name)
    return arr

def listFileOnServer():
    data_sock = ftp.enter_passive_mode(globals.control_sock)
    resp = ftp.send_cmd(globals.control_sock, "LIST")

    if "150" not in resp:
        utils.log("Không tìm thấy file trên server")
        data_sock.close()
        return []

    raw_data = b""
    while True:
        data = data_sock.recv(BUFFER_SIZE)
        if not data:
            break
        raw_data += data
    data_sock.close()

    ftp.recv_all(globals.control_sock)

    lines = raw_data.decode(errors="ignore").splitlines()
    arr = []

    for line in lines:
        if not line or line[0] == 'd':
            continue  
        filename = line.strip().split()[-1]
        arr.append(filename)

    return arr

def put():
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until current task is done")
        return
    if(not globals.control_sock):
        utils.log("[SYSTEM] Please connect")
        return
    fileList = listFileOnClient()

    if not fileList:
        utils.log("[PUT] No files found in client directory.")
        return

    def start_scan(filename, popup):
        popup.destroy()
        globals.status_var.set(f"Scanning {filename}...")

        def scan_and_upload():
            scan_result = sendToClamAV(filename)
            utils.log(f"[PUT] Result from ClamAV: {scan_result}")

            if scan_result != "OK":
                utils.log(f"[PUT] Cannot upload {filename} (infected).")
                return
            
            globals.status_var.set(f"Uploading {filename}...")
            
            if globals.is_passive:
                data_sock = ftp.enter_passive_mode(globals.control_sock)
            else:
                listen_sock = ftp.enter_active_mode(globals.control_sock)

            ftp.send_cmd(globals.control_sock, f"STOR {filename}")

            if not globals.is_passive:
                data_sock, _ = listen_sock.accept()

            with open(filename, 'rb') as f:
                while chunk := f.read(BUFFER_SIZE):
                    data_sock.sendall(chunk)
            data_sock.close()
            if not globals.is_passive:
                listen_sock.close()

            response = ftp.recv_all(globals.control_sock)
            utils.log(f"[PUT] Upload complete: {response}")
            operations.list_files(globals.control_sock)
            globals.status_var.set("Ready")

        thread = threading.Thread(target=scan_and_upload)
        thread.start()

    popup = tk.Toplevel(globals.root)
    popup.title("Select File to Upload")
    popup.geometry("300x500")
    popup.configure(bg="#55B3D9")

    tk.Label(popup, text="Select a file to upload:", bg="#55B3D9", fg="white").pack(pady=10)

    for idx, fname in enumerate(fileList):
        tk.Button(
            popup,
            text=f"{idx + 1}. {fname}",
            bg="white",
            width=30,
            command=lambda f=fname: start_scan(f, popup)
        ).pack(pady=2)

    popup.transient(globals.root)
    popup.grab_set()
    globals.root.wait_window(popup)

def get():
    if globals.status_var.get() != "Ready":
        utils.log("[SYSTEM] Please wait until current task is done")
        return
    if not globals.control_sock:
        utils.log("[SYSTEM] Please connect")
        return

    globals.status_var.set("Fetching file list...")

    def fetch_and_show_popup():
        fileList = listFileOnServer()
        if not fileList:
            utils.log("[GET] No files found on server.")
            globals.status_var.set("Ready")
            return

        def start_download(filename, popup):
            popup.destroy()
            globals.status_var.set(f"Downloading {filename}...")

            def download_file():
                if globals.is_passive:
                    data_sock = ftp.enter_passive_mode(globals.control_sock)
                else:
                    listen_sock = ftp.enter_active_mode(globals.control_sock)

                resp = ftp.send_cmd(globals.control_sock, f"RETR {filename}")
                utils.log(f"[GET] {resp.strip()}")

                if "150" not in resp:
                    utils.log(f"[GET] Cannot download {filename} from server.")
                    if globals.is_passive:
                        data_sock.close()
                    else:
                        listen_sock.close()
                    ftp.recv_all(globals.control_sock)
                    globals.status_var.set("Ready")
                    return

                if not globals.is_passive:
                    data_sock, _ = listen_sock.accept()

                with open(filename, 'wb') as f:
                    while True:
                        data = data_sock.recv(BUFFER_SIZE)
                        if not data:
                            break
                        f.write(data)

                data_sock.close()
                if not globals.is_passive:
                    listen_sock.close()

                response = ftp.recv_all(globals.control_sock)
                utils.log(f"[GET] Download complete: {response.strip()}")
                operations.list_local_files()
                globals.status_var.set("Ready")

            threading.Thread(target=download_file).start()

        def show_popup():
            popup = tk.Toplevel(globals.root)
            popup.title("Select File to Download")
            popup.geometry("300x500")
            popup.configure(bg="#55B3D9")

            tk.Label(popup, text="Select a file to download:", bg="#55B3D9", fg="white").pack(pady=10)

            for idx, fname in enumerate(fileList):
                tk.Button(
                    popup,
                    text=f"{idx + 1}. {fname}",
                    bg="white",
                    width=30,
                    command=lambda f=fname: start_download(f, popup)
                ).pack(pady=2)

            popup.transient(globals.root)
            popup.grab_set()
            globals.root.wait_window(popup)
        
        globals.root.after(0, show_popup)

    threading.Thread(target=fetch_and_show_popup).start()

def mput():
    if globals.status_var.get() != "Ready":
        utils.log("[SYSTEM] Please wait until current task is done")
        return
    if not globals.control_sock:
        utils.log("[SYSTEM] Please connect to the server")
        return

    fileList = listFileOnClient()
    if not fileList:
        utils.log("[MPUT] No files found in client directory.")
        return

    selected_files = []

    popup = tk.Toplevel(globals.root)
    popup.title("Select Files to Upload")
    popup.geometry("300x500")
    popup.configure(bg="#55B3D9")

    tk.Label(popup, text="Select files to upload:", bg="#55B3D9", fg="white").pack(pady=10)

    check_vars = []
    for fname in fileList:
        var = tk.BooleanVar()
        cb = tk.Checkbutton(popup, text=fname, variable=var, bg="white")
        cb.pack(anchor="w", padx=10)
        check_vars.append(var)

    def confirm_selection():
        for i, var in enumerate(check_vars):
            if var.get():
                selected_files.append(fileList[i])
        popup.destroy()

    tk.Button(popup, text="Upload Selected", bg="white", command=confirm_selection).pack(pady=10)

    popup.transient(globals.root)
    popup.grab_set()
    globals.root.wait_window(popup)

    if not selected_files:
        utils.log("[MPUT] No file selected.")
        return

    def process_all_files():
        for file_to_upload in selected_files:
            globals.status_var.set(f"Scanning {file_to_upload}...")
            utils.log(f"[MPUT] Scanning {file_to_upload}...")

            try:
                scan_result = sendToClamAV(file_to_upload)
            except Exception as e:
                utils.log(f"[MPUT] Error scanning {file_to_upload}: {e}")
                continue

            utils.log(f"[MPUT] Result from ClamAV ({file_to_upload}): {scan_result}")

            if scan_result != "OK":
                utils.log(f"[MPUT] Cannot upload {file_to_upload} (infected).")
                continue

            globals.status_var.set(f"Uploading {file_to_upload}...")
            utils.log(f"[MPUT] Uploading {file_to_upload}...")

            try:
                if globals.is_passive:
                    data_sock = ftp.enter_passive_mode(globals.control_sock)
                else:
                    listen_sock = ftp.enter_active_mode(globals.control_sock)

                ftp.send_cmd(globals.control_sock, f"STOR {file_to_upload}")

                if not globals.is_passive:
                    data_sock, _ = listen_sock.accept()

                with open(file_to_upload, 'rb') as f:
                    while chunk := f.read(BUFFER_SIZE):
                        data_sock.sendall(chunk)

                data_sock.close()
                if not globals.is_passive:
                    listen_sock.close()

                response = ftp.recv_all(globals.control_sock)
                utils.log(f"[MPUT] Upload complete for {file_to_upload}: {response.strip()}")

                operations.list_files(globals.control_sock)

            except Exception as e:
                utils.log(f"[MPUT] Error uploading {file_to_upload}: {e}")
                continue

        globals.status_var.set("Ready")
        utils.log("[MPUT] All selected files have been processed.")

    threading.Thread(target=process_all_files).start()

def mget():
    if globals.status_var.get() != "Ready":
        utils.log("[SYSTEM] Please wait until current task is done")
        return
    if not globals.control_sock:
        utils.log("[SYSTEM] Please connect to the server")
        return

    globals.status_var.set("Fetching file list...")

    def fetch_file_list():
        try:
            fileList = listFileOnServer()
        except Exception as e:
            utils.log(f"[MGET] Error getting file list: {e}")
            globals.root.after(0, lambda: globals.status_var.set("Ready"))
            return

        if not fileList:
            utils.log("[MGET] No files available on server.")
            globals.root.after(0, lambda: globals.status_var.set("Ready"))
            return

        # Gọi lại GUI trên main thread
        globals.root.after(0, lambda: show_file_selection_popup(fileList))

    def show_file_selection_popup(fileList):
        globals.status_var.set("Waiting for file selection...")
        selected_files = []

        popup = tk.Toplevel(globals.root)
        popup.title("Select Files to Download")
        popup.geometry("300x400")
        popup.configure(bg="#55B3D9")

        tk.Label(popup, text="Select files to download:", bg="#55B3D9", fg="white").pack(pady=10)

        check_vars = []
        for fname in fileList:
            var = tk.BooleanVar()
            cb = tk.Checkbutton(popup, text=fname, variable=var, bg="white", anchor="w")
            cb.pack(fill="x", padx=10)
            check_vars.append(var)

        def confirm_selection():
            for i, var in enumerate(check_vars):
                if var.get():
                    selected_files.append(fileList[i])
            popup.destroy()

            if not selected_files:
                utils.log("[MGET] No file selected.")
                globals.status_var.set("Ready")
                return

            # Bắt đầu tải
            threading.Thread(target=lambda: process_all_downloads(selected_files), daemon=True).start()

        tk.Button(popup, text="Download Selected", bg="white", command=confirm_selection).pack(pady=10)

        popup.transient(globals.root)
        popup.grab_set()
        globals.root.wait_window(popup)

    def process_all_downloads(selected_files):
        def set_status_safe(text):
            globals.root.after(0, lambda: globals.status_var.set(text))

        for file_to_download in selected_files:
            set_status_safe(f"Downloading {file_to_download}...")
            utils.log(f"[MGET] Downloading {file_to_download}...")

            try:
                if globals.is_passive:
                    data_sock = ftp.enter_passive_mode(globals.control_sock)
                else:
                    listen_sock = ftp.enter_active_mode(globals.control_sock)

                resp = ftp.send_cmd(globals.control_sock, f"RETR {file_to_download}")
                utils.log(f"[MGET] {resp.strip()}")

                if "150" not in resp:
                    utils.log(f"[MGET] Failed to download {file_to_download} from server.")
                    if globals.is_passive:
                        data_sock.close()
                    else:
                        listen_sock.close()
                    ftp.recv_all(globals.control_sock)
                    continue

                if not globals.is_passive:
                    data_sock, _ = listen_sock.accept()

                with open(file_to_download, 'wb') as f:
                    while True:
                        data = data_sock.recv(4096)
                        if not data:
                            break
                        f.write(data)

                data_sock.close()
                if not globals.is_passive:
                    listen_sock.close()

                response = ftp.recv_all(globals.control_sock)
                utils.log(f"[MGET] Download complete for {file_to_download}: {response.strip()}")

            except Exception as e:
                utils.log(f"[MGET] Error downloading {file_to_download}: {e}")
                continue

        operations.list_local_files()
        utils.log("[MGET] All selected files have been downloaded.")
        globals.status_var.set("Ready")
        
    # Bắt đầu luồng lấy danh sách file
    threading.Thread(target=fetch_file_list, daemon=True).start()