import globals
import operations
import session
import utils
import threading
import ftp_core as ftp
import tkinter as tk
from tkinter import filedialog, messagebox

def execute_command(command_input):
    if not command_input.strip():
        log("Please enter a command.")
        return
    
    if(not globals.control_sock):
        log("Please connect.")
        return

    if(globals.status_var.get()!="Ready"):
        log("Please wait until the current task is done")
        return

    globals.status_var.set("Executing command...")

    parts = command_input.strip().split()
    cmd = parts[0].lower()

    try:
        if cmd == "pwd":
            on_show_curr_direct()

        elif cmd == "cd":
            if len(parts) == 2:
                on_cd(parts[1])
            else:
                log("Usage: cd <remote_directory>")

        elif cmd == "lcd":
            if len(parts) == 2:
                operations.change_directory_client(parts[1])
            else:
                log("Usage: lcd <local_directory>")

        elif cmd=="help" or cmd=="?":
            session.show_cmd()

        else:
            log("Error command. Please type 'help' to see available commands.")
            log(" ")

    except Exception as e:
        log(f"[Error] {str(e)}")

    globals.status_var.set("Ready")

def log(msg):
    globals.log_text.insert(globals.tk.END, msg + "\n")
    globals.log_text.see(globals.tk.END)

# --- pwd ---
def on_show_curr_direct():
    threading.Thread(target=operations.show_curr_direct, args=(globals.control_sock,), daemon=True).start()

# --- cd ---
def on_cd(name):
    threading.Thread(target=operations.change_directory_server, args=(globals.control_sock, name), daemon=True).start()

# --- mkdir ---
def on_create_directory_click():
    if not globals.control_sock:
        log("[SYSTEM] Please connect before using this feature")
        return
    
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return

    popup = tk.Toplevel(globals.root)
    popup.title("Create New Directory")
    popup.geometry("300x120")
    popup.configure(bg="#55B3D9")

    tk.Label(popup, text="Directory name:", bg="#55B3D9", fg="black", font=("Calibri", 10)).pack(pady=5)
    
    dir_entry = tk.Entry(popup, width=30)
    dir_entry.pack(pady=5)

    def submit():
        dir_name = dir_entry.get().strip()
        if dir_name:
            popup.destroy()
            threading.Thread(
                target=lambda: create_dir(dir_name),
                daemon=True
            ).start()
        else:
            messagebox.showwarning("Invalid", "Please enter a directory name.")

    tk.Button(popup, text="Create", command=submit, bg="#2D5F73", fg="white", activebackground="#99aab5").pack(pady=5)

def create_dir(dir_name):
    try:
        globals.status_var.set("Running...")
        operations.create_directory(globals.control_sock, dir_name)
    except Exception as e:
        utils.log(f"[MKDIR] Failed to create directory: {e}")
    finally:
        globals.status_var.set("Ready")

# --- rmdir ---
def on_remove_directory_click():
    if not globals.control_sock:
        log("[SYSTEM] Please connect before using this feature")
        return
    
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return
    
    popup = tk.Toplevel(globals.root)
    popup.title("Delete Directory")
    popup.geometry("300x120")
    popup.configure(bg="#55B3D9")

    tk.Label(popup, text="Directory name:", bg="#55B3D9", fg="black", font=("Calibri", 10)).pack(pady=5)
    
    dir_entry = tk.Entry(popup, width=30)
    dir_entry.pack(pady=5)

    def submit():
        dir_name = dir_entry.get().strip()
        if dir_name:
            popup.destroy()
            threading.Thread(
                target=lambda: remove_dir(dir_name),
                daemon=True
            ).start()
        else:
            messagebox.showwarning("Invalid", "Please enter a directory name.")

    tk.Button(popup, text="Remove", command=submit, bg="#2D5F73", fg="white", activebackground="#99aab5").pack(pady=5)

def remove_dir(dir_name):
    try:
        globals.status_var.set("Running...")
        operations.remove_directory(globals.control_sock, dir_name)
    except Exception as e:
        utils.log(f"[RMDIR] Failed to remove directory: {e}")
    finally:
        globals.status_var.set("Ready")

# --- delete ---
def on_delete_file_click():
    if not globals.control_sock:
        log("[SYSTEM] Please connect before using this feature")
        return
    
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return

    popup = tk.Toplevel(globals.root)
    popup.title("Delete File")
    popup.geometry("300x120")
    popup.configure(bg="#55B3D9")

    tk.Label(popup, text="File name:", bg="#55B3D9", fg="black", font=("Calibri", 10)).pack(pady=5)
    
    file_entry = tk.Entry(popup, width=30)
    file_entry.pack(pady=5)

    def submit():
        file_name = file_entry.get().strip()
        if file_name:
            popup.destroy()
            threading.Thread(
                target=lambda: delete_file(file_name),
                daemon=True
            ).start()
        else:
            messagebox.showwarning("Invalid", "Please enter a file name.")

    tk.Button(popup, text="Delete", command=submit, bg="#2D5F73", fg="white", activebackground="#99aab5").pack(pady=5)

def delete_file(file_name):
    try:
        globals.status_var.set("Running...")
        operations.delete_file(globals.control_sock, file_name)
    except Exception as e:
        utils.log(f"[DELETE] Failed to delete file: {e}")
    finally:
        globals.status_var.set("Ready")

# --- rename ---
def on_rename_file_click():
    if not globals.control_sock:
        utils.log("[SYSTEM] Please connect before using this feature")
        return

    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return

    popup_old = tk.Toplevel(globals.root)
    popup_old.title("Rename File - Step 1")
    popup_old.geometry("300x120")
    popup_old.configure(bg="#55B3D9")

    tk.Label(popup_old, text="Old Name:", bg="#55B3D9", fg="black", font=("Calibri", 10)).pack(pady=5)
    
    old_name_entry = tk.Entry(popup_old, width=30)
    old_name_entry.pack(pady=5)

    def next_step():
        old_name = old_name_entry.get().strip()
        if not old_name:
            messagebox.showwarning("Invalid", "Please enter the old file name.", parent=popup_old)
            return
        popup_old.destroy()  
        
        popup_new = tk.Toplevel(globals.root)
        popup_new.title("Rename File - Step 2")
        popup_new.geometry("300x120")
        popup_new.configure(bg="#55B3D9")

        tk.Label(popup_new, text="New Name:", bg="#55B3D9", fg="black", font=("Calibri", 10)).pack(pady=5)
        
        new_name_entry = tk.Entry(popup_new, width=30)
        new_name_entry.pack(pady=5)

        def submit():
            new_name = new_name_entry.get().strip()
            if not new_name:
                messagebox.showwarning("Invalid", "Please enter the new file name.", parent=popup_new)
                return
            else:
                popup_new.destroy()
                threading.Thread(
                    target=lambda: rename_file(old_name, new_name),
                    daemon=True
                ).start()

        tk.Button(popup_new, text="Rename", command=submit, bg="#2D5F73", fg="white", activebackground="#99aab5").pack(pady=5)

    tk.Button(popup_old, text="Next", command=next_step, bg="#2D5F73", fg="white", activebackground="#99aab5").pack(pady=5)

def rename_file(old_name, new_name):
    try:
        globals.status_var.set("Running...")
        operations.rename_file(globals.control_sock, old_name, new_name)
    except Exception as e:
        utils.log(f"[RENAME] Failed to rename file: {e}")
    finally:
        globals.status_var.set("Ready")

# --- refresh ---
def on_go_to_root_click():
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return
    threading.Thread(target=go_to_root_thread, daemon=True).start()

def go_to_root_thread():
    if not globals.control_sock:
        utils.log("[SYSTEM] Please connect before using this feature")
        return
    try:
        globals.status_var.set("Running...")
        ftp.send_cmd(globals.control_sock, "CWD /")
        operations.list_files(globals.control_sock)
    except Exception as e:
        utils.log(f"[REFRESH] Error returning to root: {e}")
    finally:
        globals.status_var.set("Ready")