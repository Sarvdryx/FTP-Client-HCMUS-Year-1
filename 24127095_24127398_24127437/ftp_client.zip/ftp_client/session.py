import utils
import socket
import ftp_core as ftp
import operations
import globals
import re
import main
import threading

# --- Connect ---
def on_click_connect():
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return
    threading.Thread(target=connect).start()

def connect():
    globals.status_var.set("Connecting to server...")
    
    host = globals.host_entry.get().strip()
    port_str = globals.port_entry.get().strip()
    user = globals.user_entry.get().strip()
    pwd = globals.pass_entry.get().strip()

    try:
        port = int(port_str)
        globals.control_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        globals.control_sock.connect((host, port))

        utils.log(ftp.recv_all(globals.control_sock).strip())
        utils.log(ftp.send_cmd(globals.control_sock, f"USER {user}").strip())
        utils.log(ftp.send_cmd(globals.control_sock, f"PASS {pwd}").strip())

        operations.list_files(globals.control_sock)
        operations.list_local_files()
        utils.log(" ")
        show_cmd()

    except Exception as e:
        utils.log(f"Fail to connect: {e}")
    finally:
        globals.status_var.set("Ready")

# --- Disconnect ---
def on_click_disconnect():
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return
    threading.Thread(target=disconnect).start()
def disconnect():
    if globals.control_sock:
        try:
            globals.status_var.set("Disonnecting from server...")
            utils.log(ftp.send_cmd(globals.control_sock, "QUIT").strip())
            globals.control_sock.close()
        except Exception as e:
            utils.log(f"Disconnect error: {e}")
        finally:
            globals.control_sock = None

    globals.status_var.set("Ready")
    utils.log("Server disconnected.\n")

def toggle_passive():
    globals.is_passive = not globals.is_passive

    mode = "Passive" if globals.is_passive else "Active"
    utils.log(f"[PASV] Switch to {mode} mode.")
    utils.log(" ")

# --- Status ---
def on_click_show_status():
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return
    threading.Thread(target=show_status).start()
def show_status():
    globals.status_var.set("Getting status...")

    if not globals.control_sock:
        utils.log("[SYSTEM] Please connect to server.")
        globals.status_var.set("Ready")
        return

    try:
        utils.log("[STATUS] FTP Client Status:")
        utils.log(f" Connected to {globals.host_entry.get()}:{globals.port_entry.get()}")
        utils.log(f" Logged in as {globals.user_entry.get()}")
        utils.log(f" Transfer type: {globals.transfer_mode.upper()}")
        utils.log(f" Mode: {'Passive' if globals.is_passive else 'Active'}")

        # Lấy thư mục hiện tại từ server
        response = ftp.send_cmd(globals.control_sock, "PWD")
        match = re.search(r'"(.*?)"', response)
        if match:
            current_dir = match.group(1)
            utils.log(f" Current directory: {current_dir}")
        else:
            utils.log(" Current directory: Unknown")

        utils.log(" No transfer in progress")
        utils.log("[STATUS] End of status")
    except Exception as e:
        utils.log(f"[STATUS] Error getting status: {e}")
    finally:
        globals.status_var.set("Ready")
        utils.log(" ")

# --- Quit ---
def on_click_quit():
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return
    threading.Thread(target=quit,daemon = True).start()
def quit():
    if globals.control_sock:
        try:
            utils.log("Disconnecting from server...")
            response = ftp.send_cmd(globals.control_sock, "QUIT")
            globals.control_sock.close()
            globals.control_sock = None
        except Exception as e:
            utils.log(f"[QUIT] Error while disconnecting: {e}")

    utils.log("[QUIT] Quitting FTP client...")
    globals.status_var.set("Exiting...")
    globals.root.destroy()

# --- Transfer mode ---
def on_click_set_transfer():
    if(globals.status_var.get()!="Ready"):
        utils.log("[SYSTEM] Please wait until the current task is done")
        return
    threading.Thread(target=set_transfer_mode).start()

def set_transfer_mode():
    if not globals.control_sock:
        utils.log("[SYSTEM] Not connected to server.")
        return

    globals.status_var.set("Setting transfer mode...")
    mode = globals.mode_var.get().lower()

    try:
        if mode == "ascii":
            response = ftp.send_cmd(globals.control_sock, "TYPE A")
            if response.startswith("200"):
                globals.transfer_mode = "ascii"
                utils.log("[TRANSFER MODE] Switched to ASCII mode (TYPE A).")
            else:
                utils.log("[TRANSFER MODE] Failed to switch to ASCII mode.")
        else:
            response = ftp.send_cmd(globals.control_sock, "TYPE I")
            if response.startswith("200"):
                globals.transfer_mode = "binary"
                utils.log("[TRANSFER MODE] Switched to Binary mode (TYPE I).")
            else:
                utils.log("[TRANSFER MODE] Failed to switch to Binary mode.")
    except Exception as e:
        utils.log(f"[TRANSFER MODE] Error setting transfer mode: {e}")
    finally:
        globals.status_var.set("Ready")
        utils.log(" ")

# --- Help ---
def show_cmd():
    utils.log("[HELP] Command List:")
    utils.log(" cd <name>: Move to a specified directory on server")
    utils.log(" lcd <name>: Move to a specified directory on client")
    utils.log(" pwd: Show current directory on server")
    utils.log(" help/?: Show cmd")
    utils.log(" ")