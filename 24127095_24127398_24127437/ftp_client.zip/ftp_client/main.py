import tkinter as tk
from tkinter import filedialog, messagebox
import globals
import utils
import ftp_core
import operations
import session
import updown

def main():
    default_font = ("Calibri", 10)

    globals.root.configure(bg="#55B3D9")  

    style_config = {
        "bg": "#55B3D9",
        "fg": "#FBF2F2",
    }

    status_frame = tk.Frame(globals.root, bg="#2c2f33")
    status_frame.pack(side="bottom", fill="x")

    globals.status_var = tk.StringVar(value="Ready")

    status_label = tk.Label(status_frame, textvariable=globals.status_var, bg="#2c2f33", fg="#43b581", anchor="w", font=("Segoe UI", 10, "bold"))
    status_label.pack(side="left", padx=10, pady=2)

    label_style = {"bg": "#73C6D9", "fg": "#1a072e"}
    button_style = {"bg": "#2D5F73", "fg": "white", "activebackground": "#99aab5"}

    globals.root.title("FTP Client")
    globals.root.geometry("800x600")

    # --- Top: Host/User/Pass ---
    top_frame = tk.Frame(globals.root)
    top_frame.configure(bg="#55B3D9")
    top_frame.pack(pady=5)

    tk.Label(top_frame, text="Host", font=default_font, **label_style).grid(row=0, column=0)
    globals.host_entry = tk.Entry(top_frame, width=15)
    globals.host_entry.grid(row=0, column=1)

    tk.Label(top_frame, text="Port",font=default_font, **label_style).grid(row=0, column=2)
    globals.port_entry = tk.Entry(top_frame, width=5)
    globals.port_entry.grid(row=0, column=3)
    globals.port_entry.insert(0, "21")

    tk.Label(top_frame, text="User",font=default_font, **label_style).grid(row=0, column=4)
    globals.user_entry = tk.Entry(top_frame, width=10)
    globals.user_entry.grid(row=0, column=5)

    tk.Label(top_frame, text="Pass",font=default_font, **label_style).grid(row=0, column=6)
    globals.pass_entry = tk.Entry(top_frame, width=10, show="*")
    globals.pass_entry.grid(row=0, column=7)

    globals.connectBtn=tk.Button(top_frame, text="Connect", command=session.on_click_connect,font=default_font, **button_style).grid(row=0, column=8, padx=5)
    globals.disconnectBtn=tk.Button(top_frame, text="Disconnect", command=session.on_click_disconnect,font=default_font, **button_style).grid(row=0, column=9)

    # --- Transfer mode + Passive ---
    config_frame = tk.Frame(globals.root)
    config_frame.configure(bg="#55B3D9")
    config_frame.pack()

    globals.mode_var = tk.StringVar(value="binary")
    globals.passive_var = tk.BooleanVar(value=True)

    shared_style = {
        "font": default_font,
        "bg": "#73C6D9",              # Màu nền giống nhau
        "fg": "black",                # Màu chữ trắng
        "activebackground": "#73C6D9",
        "selectcolor": "white",    # Màu nền ô tick
        "relief": "groove",     # Kiểu viền (groove, raised, sunken, flat, ridge)
        "bd": 2,                # Độ dày viền (border width)
        "highlightthickness": 1
    }

    globals.asciiBtn=tk.Radiobutton(config_frame, text="ASCII", variable=globals.mode_var, value="ascii",
                command=session.on_click_set_transfer, **shared_style).pack(side="left", padx=5)

    globals.binaryBtn=tk.Radiobutton(config_frame, text="Binary", variable=globals.mode_var, value="binary",
                command=session.on_click_set_transfer, **shared_style).pack(side="left", padx=5)

    globals.checkBtn=tk.Checkbutton(config_frame, text="Passive Mode", variable=globals.passive_var,
                command=session.toggle_passive, **shared_style).pack(side="left", padx=5)


    # --- Response from server and list file(client & server) (dummy) ---
    file_frame = tk.Frame(globals.root)
    file_frame.configure(bg="#55B3D9")
    file_frame.pack(fill="both", expand=True)

    left_frame = tk.Frame(file_frame)
    left_frame.configure(bg="#55B3D9")
    left_frame.pack(side="left", fill="both", expand=True)

    list_frame = tk.LabelFrame(left_frame, text="Server",font=("Segoe UI", 12, "bold"))
    list_frame.pack(side="top", fill="both", expand=True, padx=10, pady=5)
    globals.list_text = tk.Text(list_frame, width=45, height=10,font=default_font)
    globals.list_text.pack(fill="both", expand=True)

    local_frame = tk.LabelFrame(left_frame, text="Client",font=("Segoe UI", 12, "bold"))
    local_frame.pack(side="top", fill="both", expand=True, padx=10, pady=5)
    globals.local_text = tk.Text(local_frame, width=45, height=10, font=default_font,)
    globals.local_text.pack(fill="both", expand=True)

    log_frame = tk.LabelFrame(file_frame, text="Log",font=("Segoe UI", 12, "bold"))
    log_frame.pack(side="left", fill="both", expand=True, padx=(2, 2), pady=5)
    globals.log_text = tk.Text(log_frame, width=45, height=22,font=default_font,) 
    globals.log_text.pack(fill="both", expand=True)

    right_frame = tk.Frame(file_frame, bg="#55B3D9", width=100)
    right_frame.pack(side="right", fill="y", padx=1, pady=5) 
    right_frame.pack_propagate(False)

    globals.upBtn=tk.Button(right_frame, text="Upload", command=updown.put, font=default_font, **button_style)\
        .pack(anchor="center", pady=1, fill="x")

    globals.downBtn=tk.Button(right_frame, text="Download", command=updown.get, font=default_font, **button_style)\
        .pack(anchor="center", pady=1, fill="x")

    globals.mUpBtn=tk.Button(right_frame, text="MUpload", command=updown.mput, font=default_font, **button_style)\
        .pack(anchor="center", pady=1, fill="x")

    globals.mDownBtn=tk.Button(right_frame, text="MDownload", command=updown.mget, font=default_font, **button_style)\
        .pack(anchor="center", pady=1, fill="x")

    globals.mkdirBtn=tk.Button(right_frame, text="Create directory", command=utils.on_create_directory_click, font=default_font, **button_style)\
        .pack(anchor="center", pady=1, fill="x")

    globals.rmdirBtn=tk.Button(right_frame, text="Delete diretory", command=utils.on_remove_directory_click,font=default_font, **button_style)\
        .pack(anchor="center", pady=1, fill="x")
    
    globals.delFileBtn=tk.Button(right_frame, text="Delete file", font=default_font, command=utils.on_delete_file_click, **button_style)\
        .pack(anchor="center", pady=1, fill="x")

    globals.renameFileBtn=tk.Button(right_frame, text="Rename file", font=default_font,command=utils.on_rename_file_click, **button_style)\
        .pack(anchor="center", pady=1, fill="x")
    
    globals.refreshBtn=tk.Button(right_frame, text="Refresh root", font=default_font,command=utils.on_go_to_root_click, **button_style)\
        .pack(anchor="center", pady=1, fill="x")

    # --- Command Entry ---
    command_frame = tk.Frame(globals.root)
    command_frame.configure(bg="#55B3D9")
    command_frame.pack(pady=5)

    tk.Label(command_frame, text="FTP Command:", font=default_font,**label_style).pack(side="left")
    globals.cmd_entry = tk.Entry(command_frame, width=50,font=default_font,)
    globals.cmd_entry.pack(side="left", padx=5)

    tk.Button(command_frame, text="Execute", command=lambda: utils.execute_command(globals.cmd_entry.get()),font=default_font, **button_style).pack(side="left")

    # --- Bottom buttons ---
    bottom_frame = tk.Frame(globals.root)
    bottom_frame.configure(bg="#55B3D9")
    bottom_frame.pack(pady=5)

    globals.statusBtn=tk.Button(bottom_frame, text="Status", command=session.on_click_show_status,font=default_font, **button_style).pack(side="left", padx=5)
    tk.Button(bottom_frame, text="Help", command=session.show_cmd,font=default_font, **button_style).pack(side="left", padx=5)
    globals.quitBtn=tk.Button(bottom_frame, text="Quit", command=session.on_click_quit,font=default_font, **button_style).pack(side="left", padx=5)

    globals.root.mainloop()

if __name__ == '__main__':
    main()