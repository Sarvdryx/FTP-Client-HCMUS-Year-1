import utils
import ftp_core as ftp
import globals
import re
import os

def list_files(control_sock):
    if globals.is_passive:
        data_sock = ftp.enter_passive_mode(control_sock)
        ftp.send_cmd(control_sock, 'LIST')
        output = ftp.recv_all(data_sock)

        globals.list_text.delete(1.0, globals.tk.END)
        globals.list_text.insert(globals.tk.END, output)

        data_sock.close()
        ftp.recv_all(control_sock)  
    else:
        listen_sock = ftp.enter_active_mode(control_sock)
        ftp.send_cmd(control_sock, 'LIST')
        data_sock, addr = listen_sock.accept()
        output = ftp.recv_all(data_sock)

        globals.list_text.delete(1.0, globals.tk.END)
        globals.list_text.insert(globals.tk.END, output)

        data_sock.close()
        listen_sock.close()
        ftp.recv_all(control_sock)

def list_local_files():
    globals.local_text.delete(1.0, globals.tk.END)
    current_dir = os.getcwd()
    try:
        entries = os.listdir(current_dir)
        for entry in entries:
            full_path = os.path.join(current_dir, entry)
            if os.path.isdir(full_path):
                globals.local_text.insert(globals.tk.END, f"[DIR]  {entry}\n")
            else:
                size = os.path.getsize(full_path)
                globals.local_text.insert(globals.tk.END, f"{entry}  ({size} bytes)\n")
    except Exception as e:
        globals.local_text.insert(globals.tk.END, f"Error listing local files: {e}")

def change_directory_server(control_sock, folder):
    globals.status_var.set("Running...")
    response = ftp.send_cmd(control_sock, f'CWD {folder}')

    if response.startswith('250'):
        utils.log(f"[CD] Move to folder: {folder}")
    else:
        utils.log("[CD] Cannot move to that folder.")
    list_files(control_sock)
    globals.status_var.set("Ready")
    utils.log(" ")

def change_directory_client(path):
    utils.log(f"Current directory on client: {os.getcwd()}")

    if os.path.isdir(path):
        os.chdir(path)
        utils.log(f"[LCD] Moved to: {os.getcwd()}")
    else:
        utils.log("[LCD] Directory not exist.")
    list_local_files()
    globals.status_var.set("Ready")
    utils.log(" ")

def show_curr_direct(control_sock):
    globals.status_var.set("Running...")
    response = ftp.send_cmd(control_sock, 'PWD')

    match = re.search(r'"(.*?)"', response)
    if match:
        current_dir = match.group(1)
        utils.log(f"[PWD] Current directory on server: {current_dir}")
    else:
        utils.log("[PWD] Cannot detect current directory.")
    globals.status_var.set("Ready")
    utils.log(" ")

def create_directory(control_sock, folder):
    response = ftp.send_cmd(control_sock, f"MKD {folder}")
    list_files(control_sock)
    if response.startswith("257"):
        utils.log(f"[MKDIR] Directory created: {folder}")
    else:
        utils.log("[MKDIR] Cannot create directory.")
    list_files(control_sock)
    utils.log(" ")

def remove_directory(control_sock, folder):
    pwd = ftp.send_cmd(control_sock, 'PWD')
    if f'"{folder}"' in pwd:
        utils.log("[RMDIR] You are in that directory. Please use 'cd ..' before deleting directory.")
        return

    response = ftp.send_cmd(control_sock, f"RMD {folder}")
    list_files(control_sock)
    if response.startswith("250"):
        utils.log(f"[RMDIR] Directory  deleted: {folder}")
    else:
        utils.log("[RMDIR] Cannot delete directory.")
    list_files(control_sock)
    utils.log(" ")

def delete_file(control_sock, filename):
    response = ftp.send_cmd(control_sock, f"DELE {filename}")

    if response.startswith("250"):
        utils.log(f"[DELETE] File deleted: {filename}")
    else:
        utils.log("[DELETE] Cannot delete file.")
    list_files(control_sock)
    utils.log(" ")

def rename_file(control_sock, old_name, new_name):
    resp1 = ftp.send_cmd(control_sock, f"RNFR {old_name}")

    if resp1.startswith("350"):
        resp2 = ftp.send_cmd(control_sock, f"RNTO {new_name}")
        utils.log(resp2)

        if resp2.startswith("250"):
            utils.log(f"[RENAME] File name changed: {old_name} → {new_name}")
        else:
            utils.log("RENAME] Cannot change file name.")
    else:
        utils.log("[RENAME] File not found.")
    list_files(control_sock)
    utils.log(" ")