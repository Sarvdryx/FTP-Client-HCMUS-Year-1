import socket
import re

BUFFER_SIZE=4096

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))     
        return s.getsockname()[0]      
    finally:
        s.close()

def recv_all(sock):
    sock.settimeout(5.0)
    data = b''
    try:
        while True:
            part = sock.recv(BUFFER_SIZE)
            if not part:
                break
            data += part
    except socket.timeout:
        pass
    return data.decode()

def send_cmd(sock, cmd):
    if(sock):
        sock.sendall((cmd + '\r\n').encode())
        return recv_all(sock)

def enter_passive_mode(control_sock):
    resp = send_cmd(control_sock, 'PASV')

    match = re.search(r'\((\d+,\d+,\d+,\d+,\d+,\d+)\)', resp)
    if not match:
        raise ValueError("Không tìm thấy địa chỉ IP trong phản hồi PASV.")
    
    parts = list(map(int, match.group(1).split(',')))
    ip = '.'.join(map(str, parts[:4]))
    port = parts[4] * 256 + parts[5]

    data_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    data_sock.connect((ip, port))
    return data_sock

def enter_active_mode(control_sock):
    listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ip = get_local_ip()

    listen_sock.bind((ip, 5000))  
    listen_sock.listen(1)

    ip_parts = ip.split('.')
    port = listen_sock.getsockname()[1]
    p1 = port // 256
    p2 = port % 256

    port_command = ','.join(ip_parts + [str(p1), str(p2)])
    resp = send_cmd(control_sock, f'PORT {port_command}')
    print(f"[PORT response] {resp}")

    return listen_sock