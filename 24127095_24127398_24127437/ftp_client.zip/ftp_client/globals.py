#store global variable of the entire program
import tkinter as tk
from pathlib import Path

control_sock = None
is_passive = True
transfer_mode = "binary"
root = tk.Tk()

host_entry = port_entry = user_entry = pass_entry = log_text =\
      list_text = mode_var = local_text = status_var = cmd_entry = None

mkdirBtn= connectBtn=disconnectBtn=asciiBtn=\
    binaryBtn=checkBtn=upBtn=downBtn=mUpBtn=\
        mDownBtn=rmdirBtn=delFileBtn=renameFileBtn=\
            refreshBtn=statusBtn=quitBtn=None 